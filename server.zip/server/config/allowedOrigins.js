const allowedOrigins = [
  "http://localhost:3000",
  "http://localhost:3001",
  "http://gapbor.jsdev.uz",
];

module.exports = allowedOrigins;
